// FILE: apps/storefront/src/app/checkout/_components/OrderSummary.tsx
"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ArrowLeft,
  Lock,
  ShieldCheck,
  Ticket,
  AlertTriangle,
  ShoppingCart,
  Package,
} from "lucide-react";

type SummaryItem = {
  id: string;
  product_id: string;
  variant_id: string | null;
  qty: number;
  line_key: string;
  unit_price: number;
  title: string;
  image_url: string | null;
};

type Summary = {
  cart_id: string;
  currency: string;
  items?: SummaryItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  payment_fee?: number;
  payment_method?: string | null;
  tax: number;
  total: number;
  coupon: null | { code: string; discount: number };
};

type SummaryPatchEventDetail = {
  patch?: Partial<
    Pick<
      Summary,
      | "shipping"
      | "tax"
      | "discount"
      | "payment_fee"
      | "payment_method"
      | "total"
    >
  >;
  summary?: Summary;
  reconcile?: boolean;
};

type StockIssue = {
  kind: "product" | "variant";
  product_id: string;
  variant_id: string | null;
  product_name: string;
  requested_qty: number;
  available_qty: number;
  action_url?: string;
};

type ApiErrorResponse = {
  ok?: boolean;
  error?: string;
  message_ar?: string;
  summary?: Summary;
  stock_issue?: StockIssue;
  order?: {
    id?: string;
    public_token?: string;
    public_no?: number | string;
  };
};

function n(x: any) {
  const v = Number(x ?? 0);
  return Number.isFinite(v) ? v : 0;
}

function round2(x: number) {
  return Math.round(x * 100) / 100;
}

function applyPatch(base: Summary, patch: Partial<Summary>): Summary {
  const next: Summary = {
    ...base,
    ...patch,
  };

  const subtotal = n(next.subtotal);
  const shipping = n(next.shipping);
  const payment_fee = n(next.payment_fee);
  const discount = n(next.discount);

  next.total = round2(
    Math.max(0, subtotal - discount) + shipping + payment_fee,
  );

  return next;
}

function isCartEmptyError(message: string | null | undefined) {
  const v = String(message ?? "").trim().toUpperCase();

  return (
    v === "CART_EMPTY" ||
    v.includes("CART_EMPTY") ||
    v === "سلة المشتريات فارغة." ||
    v.includes("سلة المشتريات فارغة")
  );
}

function buildReadablePrepareError(raw: string | null | undefined) {
  if (isCartEmptyError(raw)) {
    return "بعض المنتجات في هذه السلة لم تعد متاحة، أو تم إخفاؤها من المتجر، لذلك لا يمكن إكمال الطلب حالياً.";
  }

  return raw || "تعذر تحديث ملخص الطلب حالياً.";
}

function buildReadableSubmitError(j: ApiErrorResponse) {
  if (j?.stock_issue) {
    const issue = j.stock_issue;

    if (n(issue.available_qty) <= 0) {
      return `المنتج "${issue.product_name}" نفدت كميته. حدّث حقيبة التسوق للمتابعة.`;
    }

    return `المنتج "${issue.product_name}" لم تعد كميته المتاحة كافية. المطلوب ${issue.requested_qty} والمتاح الآن ${issue.available_qty}.`;
  }

  if (isCartEmptyError(j?.message_ar || j?.error)) {
    return "بعض المنتجات في طلبك لم تعد متاحة أو لم تعد قابلة للشراء، لذلك يلزم مراجعة السلة أولاً.";
  }

  return j?.message_ar || j?.error || "SUBMIT_FAILED";
}

function CheckoutUnavailableCard({ message }: { message: string }) {
  return (
    <div className="rounded-[24px] border border-amber-300/70 bg-amber-50/85 p-4 text-right">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-amber-100 text-amber-800">
          <AlertTriangle className="h-4 w-4" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="text-sm font-black text-amber-950">
            تعذر متابعة إتمام الطلب
          </div>

          <div className="mt-1 text-[13px] leading-6 text-amber-900">
            {message}
          </div>

          <div className="mt-3 rounded-2xl border border-amber-200 bg-white/75 px-3 py-3 text-[12px] leading-6 text-amber-950">
            قد يكون السبب أن المنتج:
            <div className="mt-1 space-y-1">
              <div>• تم إخفاؤه من الإدارة.</div>
              <div>• لم يعد ظاهرًا في الويب.</div>
              <div>• نفدت كميته أثناء وجودك في صفحة الدفع.</div>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Link
              href="/cart"
              className="inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-zinc-950 px-4 text-sm font-black text-white transition hover:bg-zinc-800"
            >
              <ShoppingCart className="h-4 w-4" />
              الانتقال إلى سلة التسوق
            </Link>

            <Link
              href="/"
              className="inline-flex h-10 items-center justify-center rounded-2xl border border-zinc-200 bg-white px-4 text-sm font-bold text-zinc-700 transition hover:bg-zinc-50"
            >
              متابعة التسوق
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function OrderSummary() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);

  const [couponCode, setCouponCode] = useState("");
  const [couponBusy, setCouponBusy] = useState(false);

  const [submitBusy, setSubmitBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [stockIssue, setStockIssue] = useState<StockIssue | null>(null);
  const [canSubmit, setCanSubmit] = useState(false);

  const hasTotals = Boolean(summary);
  const isUnavailableState =
    !loading && !summary && (isCartEmptyError(errorMsg) || Boolean(errorMsg));

  const items = Array.isArray(summary?.items) ? summary.items : [];
  const itemCount = items.reduce(
    (acc, item) => acc + Math.max(1, Math.floor(n(item.qty) || 1)),
    0,
  );

  const subtotal = hasTotals ? summary!.subtotal : null;
  const shipping = hasTotals ? summary!.shipping : null;
  const payment_fee = hasTotals ? n(summary!.payment_fee) : null;
  const discount = hasTotals ? summary!.discount : null;
  const total = hasTotals ? summary!.total : null;

  const currency = summary?.currency ?? "SAR";
  const hasCouponApplied = Boolean(summary?.coupon?.code);

  const abortRef = useRef<AbortController | null>(null);
  const seqRef = useRef(0);

  async function fetchPrepare(reason?: string) {
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    const seq = ++seqRef.current;

    setLoading(true);
    setErrorMsg(null);

    try {
      const r = await fetch("/api/checkout/prepare", {
        method: "GET",
        signal: ac.signal,
        headers: { "Cache-Control": "no-store" },
      });

      const j = (await r.json().catch(() => ({}))) as any;

      if (seq !== seqRef.current) return;

      if (!r.ok || !j?.ok) {
        const raw =
          j?.message_ar ||
          j?.error ||
          (reason ? `PREPARE_FAILED:${reason}` : "PREPARE_FAILED");

        throw new Error(raw);
      }

      const s: Summary = j.summary;
      setSummary(s);

      if (s?.coupon?.code) setCouponCode(String(s.coupon.code));
      else setCouponCode("");
    } catch (e: any) {
      if (e?.name === "AbortError") return;

      const raw = e?.message || "PREPARE_FAILED";
      setErrorMsg(raw);
      setSummary(null);
    } finally {
      if (seq === seqRef.current) setLoading(false);
    }
  }

  useEffect(() => {
    fetchPrepare("mount");

    const onRefresh = () => fetchPrepare("refresh");

    const onSummaryPatch = (evt: Event) => {
      const e = evt as CustomEvent<SummaryPatchEventDetail>;
      const detail = e?.detail || {};

      if (detail.summary) {
        setSummary(detail.summary);

        if (detail.summary?.coupon?.code) {
          setCouponCode(String(detail.summary.coupon.code));
        } else {
          setCouponCode("");
        }
      }

      if (detail.patch) {
        setSummary((prev) => {
          if (!prev) return prev;
          return applyPatch(prev, detail.patch as Partial<Summary>);
        });
      }

      const reconcile = detail.reconcile !== false;
      if (reconcile) fetchPrepare("reconcile");
    };

    const onSubmitEnabled = (evt: Event) => {
      const e = evt as CustomEvent<{ enabled?: boolean }>;
      setCanSubmit(Boolean(e?.detail?.enabled));
    };

    window.addEventListener("checkout:refresh", onRefresh as EventListener);
    window.addEventListener(
      "checkout:summaryPatch",
      onSummaryPatch as EventListener,
    );
    window.addEventListener(
      "checkout:submitEnabled",
      onSubmitEnabled as EventListener,
    );

    return () => {
      window.removeEventListener(
        "checkout:refresh",
        onRefresh as EventListener,
      );
      window.removeEventListener(
        "checkout:summaryPatch",
        onSummaryPatch as EventListener,
      );
      window.removeEventListener(
        "checkout:submitEnabled",
        onSubmitEnabled as EventListener,
      );
      abortRef.current?.abort();
    };
  }, []);

  async function applyCoupon() {
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    setCouponBusy(true);
    setErrorMsg(null);
    setStockIssue(null);

    try {
      const r = await fetch("/api/checkout/apply-coupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });

      const j = (await r.json().catch(() => ({}))) as ApiErrorResponse;

      if (!r.ok || !j?.ok) {
        throw new Error(j?.message_ar || j?.error || "APPLY_COUPON_FAILED");
      }

      const s: Summary = j.summary as Summary;
      setSummary(s);

      if (s?.coupon?.code) setCouponCode(String(s.coupon.code));
    } catch (e: any) {
      setErrorMsg(e?.message || "APPLY_COUPON_FAILED");
    } finally {
      setCouponBusy(false);
    }
  }

  async function removeCoupon() {
    setCouponBusy(true);
    setErrorMsg(null);
    setStockIssue(null);

    try {
      const r = await fetch("/api/checkout/remove-coupon", { method: "POST" });
      const j = (await r.json().catch(() => ({}))) as ApiErrorResponse;

      if (!r.ok || !j?.ok) {
        throw new Error(j?.message_ar || j?.error || "REMOVE_COUPON_FAILED");
      }

      const s: Summary = j.summary as Summary;
      setSummary(s);
      setCouponCode("");
    } catch (e: any) {
      setErrorMsg(e?.message || "REMOVE_COUPON_FAILED");
    } finally {
      setCouponBusy(false);
    }
  }

  async function submitOrder() {
    if (!canSubmit) return;

    setSubmitBusy(true);
    setErrorMsg(null);
    setStockIssue(null);

    try {
      const r = await fetch("/api/checkout/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      const j = (await r.json().catch(() => ({}))) as ApiErrorResponse;

      if (!r.ok || !j?.ok) {
        if (j?.stock_issue) {
          setStockIssue(j.stock_issue);
          setErrorMsg(buildReadableSubmitError(j));
          window.dispatchEvent(new CustomEvent("checkout:refresh"));
          return;
        }

        throw new Error(buildReadableSubmitError(j));
      }

      const token = j?.order?.public_token ? String(j.order.public_token) : "";

      if (!token) {
        throw new Error("تم إنشاء الطلب لكن لم يتم استلام رقم التتبع للعرض.");
      }

      window.location.href = `/thankyou/${encodeURIComponent(token)}`;
    } catch (e: any) {
      setErrorMsg(e?.message || "SUBMIT_FAILED");
    } finally {
      setSubmitBusy(false);
    }
  }

  const couponButtonLabel = useMemo(() => {
    if (hasCouponApplied) return "إزالة";
    return "تطبيق";
  }, [hasCouponApplied]);

  const submitButtonLabel = useMemo(() => {
    if (submitBusy) return "جاري تأكيد الطلب...";
    if (!canSubmit) return "أكمل الخطوات أولًا";
    return "تأكيد الدفع";
  }, [submitBusy, canSubmit]);

  const showPaymentFee = payment_fee != null && payment_fee > 0;
  const showSkeleton = loading && !summary;
  const overlayActive = loading && !!summary;

  return (
    <Card className="relative overflow-hidden rounded-[30px] border border-zinc-200 bg-white shadow-[0_22px_70px_rgba(15,23,42,0.075)]">
      {overlayActive ? (
        <div
          className="absolute inset-0 z-10 flex items-center justify-center bg-white/74 backdrop-blur-[1px]"
          aria-hidden
        >
          <div className="flex items-center gap-2 rounded-full border border-zinc-200 bg-white px-3 py-2 text-[12px] font-bold text-zinc-500 shadow-sm">
            <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-300 border-t-zinc-950" />
            جاري تحديث الملخص...
          </div>
        </div>
      ) : null}

      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[18px] font-black tracking-tight text-zinc-950">
              ملخص الطلب
            </div>

            <div className="mt-0.5 text-[13px] leading-5 text-zinc-500">
              {showSkeleton ? "جاري تجهيز الملخص..." : `${itemCount} منتجات`}
            </div>
          </div>

          {!isUnavailableState ? (
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-white px-2.5 py-1 text-[12px] font-bold text-zinc-500 shadow-sm">
                <Lock className="h-3.5 w-3.5 text-zinc-700" />
                آمن
              </span>

              <span className="inline-flex items-center rounded-full border border-zinc-200 bg-zinc-50 px-2.5 py-1 text-[12px] font-bold text-zinc-500 shadow-sm">
                {currency}
              </span>
            </div>
          ) : null}
        </div>

        <div className="my-4 h-px w-full bg-gradient-to-r from-transparent via-zinc-200 to-transparent" />

        {isUnavailableState ? (
          <CheckoutUnavailableCard
            message={buildReadablePrepareError(errorMsg)}
          />
        ) : (
          <>
            {stockIssue ? (
              <div className="mb-4 rounded-[24px] border border-amber-300/70 bg-amber-50/85 p-4 text-right">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-amber-100 text-amber-800">
                    <AlertTriangle className="h-4 w-4" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-black text-amber-950">
                      تغير المخزون قبل إتمام الطلب
                    </div>

                    <div className="mt-1 text-[13px] leading-6 text-amber-900">
                      {errorMsg}
                    </div>

                    <div className="mt-3 space-y-1 rounded-2xl border border-amber-200 bg-white/70 px-3 py-2 text-[12px] leading-6 text-amber-950">
                      <div>
                        <span className="font-bold">المنتج:</span>{" "}
                        {stockIssue.product_name}
                      </div>
                      <div>
                        <span className="font-bold">الكمية المطلوبة:</span>{" "}
                        {stockIssue.requested_qty}
                      </div>
                      <div>
                        <span className="font-bold">المتاح الآن:</span>{" "}
                        {stockIssue.available_qty}
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        className="rounded-2xl border-amber-300 bg-white font-black text-amber-950 hover:bg-amber-50"
                        onClick={() => {
                          window.dispatchEvent(new CustomEvent("cart:changed"));
                          window.location.href = stockIssue.action_url || "/cart";
                        }}
                      >
                        تحديث حقيبة التسوق
                      </Button>

                      <Link
                        href={stockIssue.action_url || "/cart"}
                        className="inline-flex h-10 items-center justify-center rounded-2xl border border-amber-200 bg-white px-4 text-sm font-bold text-amber-950 transition hover:bg-amber-50"
                      >
                        العودة إلى السلة
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}

            <div className="space-y-3">
              {showSkeleton ? (
                <>
                  <SummaryItemSkeleton />
                  <SummaryItemSkeleton />
                  <SummaryItemSkeleton />
                </>
              ) : items.length > 0 ? (
                <div className="max-h-[250px] space-y-2.5 overflow-y-auto pe-1">
                  {items.map((item) => (
                    <SummaryItemRow
                      key={item.id}
                      item={item}
                      currency={currency}
                    />
                  ))}
                </div>
              ) : (
                <div className="rounded-[22px] border border-dashed border-zinc-200 bg-zinc-50 px-4 py-5 text-center">
                  <Package className="mx-auto h-5 w-5 text-zinc-400" />
                  <div className="mt-2 text-sm font-black text-zinc-700">
                    لا توجد منتجات في الملخص
                  </div>
                </div>
              )}
            </div>

            <div className="my-4 h-px w-full bg-gradient-to-r from-transparent via-zinc-200 to-transparent" />

            <div className="space-y-2.5 text-[13px]">
              <Row
                label="المجموع الفرعي"
                value={
                  showSkeleton
                    ? null
                    : subtotal == null
                      ? null
                      : formatMoney(currency, subtotal)
                }
              />

              <Row
                label="الشحن"
                value={
                  showSkeleton
                    ? null
                    : shipping == null
                      ? null
                      : formatMoney(currency, shipping)
                }
              />

              {showSkeleton ? (
                <Row label="رسوم الدفع عند الاستلام" value={null} />
              ) : showPaymentFee ? (
                <Row
                  label="رسوم الدفع عند الاستلام"
                  value={formatMoney(currency, payment_fee)}
                />
              ) : null}

              {!showSkeleton && discount != null && discount > 0 ? (
                <div className="flex items-center justify-between gap-3">
                  <div className="text-zinc-500">خصم</div>
                  <div dir="ltr" className="font-black text-amber-800">
                    - {formatMoney(currency, discount)}
                  </div>
                </div>
              ) : null}
            </div>

            <div className="mt-4 rounded-[24px] bg-zinc-950 p-4 text-white shadow-[0_16px_42px_rgba(15,23,42,0.22)]">
              <div className="flex items-end justify-between gap-3">
                <div>
                  <div className="text-[13px] font-bold text-white/70">
                    الإجمالي
                  </div>

                  <div className="mt-0.5 text-[11px] leading-5 text-white/45">
                    شامل الشحن{showPaymentFee ? " ورسوم الدفع" : ""}
                  </div>
                </div>

                {showSkeleton || total == null ? (
                  <div className="h-8 w-28 animate-pulse rounded-full bg-white/15" />
                ) : (
                  <div
                    dir="ltr"
                    className="text-[29px] font-black tracking-tight text-white"
                  >
                    {formatMoney(currency, total)}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-3 rounded-[22px] border border-zinc-200 bg-zinc-50/65 p-3">
              <div className="mb-2 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Ticket className="h-4 w-4 text-zinc-600" />

                  <div>
                    <div className="text-sm font-black text-zinc-950">
                      كوبون خصم
                    </div>
                    <div className="mt-0.5 text-[11px] leading-4 text-zinc-500">
                      يُطبّق مباشرة على الإجمالي
                    </div>
                  </div>
                </div>

                <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] font-bold text-zinc-500">
                  اختياري
                </span>
              </div>

              <div className="flex gap-2">
                <Input
                  placeholder="أدخل رمز الكوبون"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="h-10 rounded-2xl border-zinc-200 bg-white text-[13px] focus-visible:ring-2 focus-visible:ring-zinc-950/10"
                  disabled={couponBusy || loading}
                />

                <Button
                  variant="outline"
                  className="h-10 rounded-2xl border-zinc-200 bg-white px-4 text-[13px] font-black text-zinc-800 shadow-sm transition hover:bg-zinc-50 active:scale-[0.99]"
                  disabled={
                    loading ||
                    couponBusy ||
                    (!hasCouponApplied && !couponCode.trim())
                  }
                  onClick={hasCouponApplied ? removeCoupon : applyCoupon}
                >
                  {couponBusy ? "..." : couponButtonLabel}
                </Button>
              </div>
            </div>

            <div className="mt-4">
              <Button
                className={[
                  "h-12 w-full rounded-[22px] text-[16px] font-black",
                  "bg-zinc-950 text-white shadow-[0_16px_42px_rgba(15,23,42,0.22)]",
                  "transition hover:bg-zinc-800 active:scale-[0.99]",
                  "disabled:bg-zinc-300 disabled:text-white disabled:shadow-none",
                ].join(" ")}
                disabled={loading || submitBusy || !hasTotals || !canSubmit}
                onClick={submitOrder}
              >
                {submitButtonLabel}
              </Button>

              <div className="mt-2 text-center text-[11px] leading-relaxed text-zinc-500">
                بالضغط على “تأكيد الدفع” سيتم إنشاء الطلب ومتابعته حسب بياناتك
                المختارة.
              </div>

              {errorMsg && !stockIssue ? (
                <div className="mt-2 rounded-2xl border border-red-500/15 bg-red-500/5 px-3 py-2 text-center text-[11px] leading-5 text-red-700">
                  {isCartEmptyError(errorMsg)
                    ? "تعذر إكمال الدفع لأن بعض المنتجات لم تعد متاحة."
                    : errorMsg}
                </div>
              ) : null}
            </div>

            <div className="mt-4 flex items-center justify-between text-[11px] text-zinc-500">
              <span className="inline-flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4" />
                دفع آمن ومشفّر
              </span>

              <Link
                href="/cart"
                className="inline-flex items-center gap-1 font-bold transition hover:text-zinc-950"
              >
                رجوع للسلة <ArrowLeft className="h-3.5 w-3.5" />
              </Link>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function SummaryItemRow({
  item,
  currency,
}: {
  item: SummaryItem;
  currency: string;
}) {
  const qty = Math.max(1, Math.floor(n(item.qty) || 1));
  const lineTotal = round2(n(item.unit_price) * qty);

  return (
    <div className="flex items-center justify-between gap-3 rounded-[20px] border border-zinc-200 bg-white p-2.5 shadow-[0_8px_22px_rgba(15,23,42,0.035)]">
      <div className="flex min-w-0 items-center gap-3">
        <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-2xl border border-zinc-200 bg-zinc-50">
          {item.image_url ? (
            <img
              src={item.image_url}
              alt={item.title}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="grid h-full w-full place-items-center text-zinc-400">
              <Package className="h-5 w-5" />
            </div>
          )}

          <span className="absolute right-1 top-1 grid h-5 min-w-[20px] place-items-center rounded-full bg-zinc-950 px-1 text-[10px] font-black leading-none text-white">
            {qty}
          </span>
        </div>

        <div className="min-w-0">
          <div className="line-clamp-2 text-[13px] font-black leading-5 text-zinc-950">
            {item.title}
          </div>

          <div className="mt-0.5 text-[11px] leading-4 text-zinc-500">
            الكمية: {qty}
          </div>
        </div>
      </div>

      <div dir="ltr" className="shrink-0 text-[13px] font-black text-zinc-950">
        {formatMoney(currency, lineTotal)}
      </div>
    </div>
  );
}

function SummaryItemSkeleton() {
  return (
    <div className="flex items-center gap-3 rounded-[20px] border border-zinc-200 bg-white p-2.5">
      <div className="h-14 w-14 animate-pulse rounded-2xl bg-zinc-100" />

      <div className="min-w-0 flex-1">
        <div className="h-4 w-32 animate-pulse rounded-full bg-zinc-100" />
        <div className="mt-2 h-3 w-20 animate-pulse rounded-full bg-zinc-100" />
      </div>

      <div className="h-4 w-16 animate-pulse rounded-full bg-zinc-100" />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string | null }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="text-zinc-500">{label}</div>

      {value == null ? (
        <SkeletonText widthClass="w-16" heightClass="h-4" />
      ) : (
        <div dir="ltr" className="font-black text-zinc-950">
          {value}
        </div>
      )}
    </div>
  );
}

function SkeletonText({
  widthClass,
  heightClass,
}: {
  widthClass: string;
  heightClass: string;
}) {
  return (
    <div
      className={["animate-pulse rounded-full bg-zinc-200", widthClass, heightClass].join(
        " ",
      )}
      aria-hidden
    />
  );
}

function formatMoney(currency: string, v: number) {
  return `${currency} ${Number(v).toLocaleString("en-US")}`;
}