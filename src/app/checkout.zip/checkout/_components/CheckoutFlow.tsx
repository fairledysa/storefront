// FILE: apps/storefront/src/app/checkout/_components/CheckoutFlow.tsx
"use client";

import { useState } from "react";
import CheckoutSteps from "./CheckoutSteps";
import AddressStep from "./AddressStep";
import ShippingStep from "./ShippingStep";
import PaymentStep from "./PaymentStep";

type StepKey = "address" | "shipping" | "payment";

async function safeJson(r: Response) {
  try {
    return await r.json();
  } catch {
    return null;
  }
}

function refreshSummary() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("checkout:refresh"));
  }
}

function setSubmitEnabled(enabled: boolean) {
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("checkout:submitEnabled", {
        detail: { enabled },
      }),
    );
  }
}

export default function CheckoutFlow() {
  const [active, setActive] = useState<StepKey>("address");

  const [done, setDone] = useState({
    address: false,
    shipping: false,
    payment: false,
  });

  const [confirmed, setConfirmed] = useState<{
    addressId?: string;
    shippingId?: string;
  }>({});

  async function confirmCheckout(patch: Record<string, any>) {
    const r = await fetch("/api/checkout/confirm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
      cache: "no-store",
    });

    const j = await safeJson(r);

    if (!r.ok) {
      const msg =
        (j && (j.error || j.message)) ||
        `CONFIRM_HTTP_${r.status}` ||
        "CONFIRM_FAILED";
      throw new Error(msg);
    }

    if (!j || j.ok !== true) {
      const msg = (j && (j.error || j.message)) || "CONFIRM_BAD_RESPONSE";
      throw new Error(msg);
    }

    return j;
  }

  function goToStep(step: StepKey) {
    if (step === active) return;

    if (step === "address") {
      setDone((d) => ({
        ...d,
        address: false,
        shipping: false,
        payment: false,
      }));
      setActive("address");
      setSubmitEnabled(false);
      return;
    }

    if (step === "shipping") {
      if (!done.address) return;

      setDone((d) => ({
        ...d,
        shipping: false,
        payment: false,
      }));
      setActive("shipping");
      setSubmitEnabled(false);
      return;
    }

    if (step === "payment") {
      if (!done.shipping) return;

      setDone((d) => ({
        ...d,
        payment: false,
      }));
      setActive("payment");
      setSubmitEnabled(false);
    }
  }

  return (
    <section className="space-y-4">
      <CheckoutSteps active={active} done={done} onStepClick={goToStep} />

      {active === "address" ? (
        <AddressStep
          isActive
          isDone={done.address}
          confirmedId={confirmed.addressId}
          onEdit={() => goToStep("address")}
          onConfirm={async (addressId) => {
            try {
              await confirmCheckout({ address_id: addressId });
            } catch (e) {
              console.error(e);
              return;
            }

            setConfirmed((c) => ({ ...c, addressId }));
            setDone((d) => ({ ...d, address: true }));
            setActive("shipping");
            setSubmitEnabled(false);
            refreshSummary();
          }}
        />
      ) : null}

      {active === "shipping" ? (
        <ShippingStep
          isActive
          isDone={done.shipping}
          isLocked={!done.address}
          confirmedId={confirmed.shippingId}
          onEdit={() => goToStep("shipping")}
          onConfirm={async (shippingId) => {
            try {
              await confirmCheckout({ shipping_id: shippingId });
            } catch (e) {
              console.error(e);
              return;
            }

            setConfirmed((c) => ({ ...c, shippingId }));
            setDone((d) => ({ ...d, shipping: true, payment: false }));
            setActive("payment");
            setSubmitEnabled(false);
            refreshSummary();
          }}
        />
      ) : null}

      {active === "payment" ? (
        <PaymentStep
          isActive
          isDone={done.payment}
          isLocked={!done.shipping}
          onEdit={() => goToStep("payment")}
          onConfirm={async () => {
            setDone((d) => ({ ...d, payment: true }));
            refreshSummary();
          }}
        />
      ) : null}
    </section>
  );
}