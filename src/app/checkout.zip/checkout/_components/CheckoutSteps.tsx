// FILE: apps/storefront/src/app/checkout/_components/CheckoutSteps.tsx
"use client";

import { Check, Lock, ShoppingBag } from "lucide-react";

type StepKey = "address" | "shipping" | "payment";
type VisualKey = "cart" | "address" | "shipping" | "payment" | "confirm";

type DoneState = {
  address: boolean;
  shipping: boolean;
  payment: boolean;
};

const steps: Array<{
  id: number;
  key: VisualKey;
  realKey?: StepKey;
  title: string;
}> = [
  { id: 1, key: "cart", title: "السلة" },
  { id: 2, key: "address", realKey: "address", title: "العنوان" },
  { id: 3, key: "shipping", realKey: "shipping", title: "الشحن" },
  { id: 4, key: "payment", realKey: "payment", title: "الدفع" },
  { id: 5, key: "confirm", title: "التأكيد" },
];

function getVisualActive(active: StepKey, done: DoneState): VisualKey {
  if (done.payment) return "confirm";
  return active;
}

function visualIndex(key: VisualKey) {
  return steps.findIndex((s) => s.key === key);
}

function isCompleted(key: VisualKey, done: DoneState) {
  if (key === "cart") return true;
  if (key === "address") return done.address;
  if (key === "shipping") return done.shipping;
  if (key === "payment") return done.payment;
  return false;
}

function isLocked(key: VisualKey, done: DoneState) {
  if (key === "cart") return false;
  if (key === "address") return false;
  if (key === "shipping") return !done.address;
  if (key === "payment") return !done.shipping;
  if (key === "confirm") return !done.payment;
  return true;
}

function getStatusLabel(
  key: VisualKey,
  activeVisual: VisualKey,
  done: DoneState,
) {
  if (isCompleted(key, done)) return "تم";
  if (key === activeVisual) return "الحالية";
  return "بانتظارك";
}

export default function CheckoutSteps({
  active,
  done,
  onStepClick,
}: {
  active: StepKey;
  done: DoneState;
  onStepClick?: (step: StepKey) => void;
}) {
  const activeVisual = getVisualActive(active, done);
  const activeIdx = Math.max(0, visualIndex(activeVisual));
  const pct = Math.max(0, Math.min(100, (activeIdx / (steps.length - 1)) * 100));
  const activeStep = steps[activeIdx] ?? steps[0];

  return (
    <div
      className={[
        "rounded-[22px] border border-zinc-200 bg-white shadow-[0_10px_28px_rgba(15,23,42,0.04)]",
        "px-3 py-2.5 sm:rounded-[26px] sm:p-4 sm:shadow-[0_14px_38px_rgba(15,23,42,0.045)]",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[16px] font-black tracking-tight text-zinc-950 sm:text-[18px]">
            إتمام الطلب
          </div>

          <div className="mt-0.5 hidden text-[13px] leading-5 text-zinc-500 sm:block">
            خطوات واضحة لإكمال طلبك بدون تعقيد
          </div>

          <div className="mt-0.5 text-[11px] leading-4 text-zinc-500 sm:hidden">
            {activeStep.title} — {getStatusLabel(activeStep.key, activeVisual, done)}
          </div>
        </div>

        <div className="inline-flex shrink-0 items-center rounded-full border border-zinc-200 bg-zinc-50 px-2.5 py-1 text-[11px] font-black text-zinc-700 sm:px-3 sm:py-1.5 sm:text-[12px]">
          الخطوة {activeIdx + 1} من 5
        </div>
      </div>

      {/* Mobile compact stepper */}
      <div className="mt-2.5 sm:hidden">
        <div className="h-1 overflow-hidden rounded-full bg-zinc-100">
          <div
            className="h-full rounded-full bg-zinc-950 transition-all duration-300"
            style={{ width: `${pct}%` }}
          />
        </div>

        <div className="mt-2 grid grid-cols-5 gap-0.5">
          {steps.map((step) => {
            const current = step.key === activeVisual;
            const completed = isCompleted(step.key, done);
            const locked = isLocked(step.key, done);
            const clickable = Boolean(
              step.realKey && onStepClick && (current || completed) && !locked,
            );

            return (
              <button
                key={step.key}
                type="button"
                disabled={!clickable}
                onClick={() => {
                  if (!clickable || !step.realKey) return;
                  onStepClick?.(step.realKey);
                }}
                className={[
                  "flex min-w-0 flex-col items-center rounded-2xl px-1 py-1.5 transition",
                  current ? "bg-zinc-50 shadow-sm" : "",
                  clickable ? "active:scale-[0.98]" : "",
                ].join(" ")}
              >
                <div
                  className={[
                    "grid h-7 w-7 place-items-center rounded-full border text-[11px] font-black",
                    current
                      ? "border-zinc-950 bg-zinc-950 text-white"
                      : completed
                        ? "border-zinc-300 bg-white text-zinc-950"
                        : locked
                          ? "border-zinc-200 bg-white text-zinc-300"
                          : "border-zinc-300 bg-white text-zinc-600",
                  ].join(" ")}
                >
                  {step.key === "cart" ? (
                    <ShoppingBag className="h-3.5 w-3.5" />
                  ) : completed ? (
                    <Check className="h-3.5 w-3.5" />
                  ) : locked ? (
                    <Lock className="h-3 w-3" />
                  ) : (
                    step.id
                  )}
                </div>

                <div
                  className={[
                    "mt-1 max-w-full truncate text-[10px] font-black leading-4",
                    current ? "text-zinc-950" : "text-zinc-400",
                  ].join(" ")}
                >
                  {step.title}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Desktop/tablet stepper */}
      <div className="relative mt-5 hidden sm:block">
        <div className="relative px-2">
          <div className="absolute left-[8%] right-[8%] top-[18px] h-px border-t border-dashed border-zinc-300" />

          <div
            className="absolute right-[8%] top-[18px] h-[2px] rounded-full bg-zinc-950 transition-all duration-300"
            style={{ width: `calc(${pct}% * 0.84)` }}
          />

          <div className="relative z-10 grid grid-cols-5 gap-2">
            {steps.map((step) => {
              const current = step.key === activeVisual;
              const completed = isCompleted(step.key, done);
              const locked = isLocked(step.key, done);
              const clickable = Boolean(
                step.realKey &&
                  onStepClick &&
                  (current || completed) &&
                  !locked,
              );

              return (
                <button
                  key={step.key}
                  type="button"
                  disabled={!clickable}
                  onClick={() => {
                    if (!clickable || !step.realKey) return;
                    onStepClick?.(step.realKey);
                  }}
                  className={[
                    "group flex flex-col items-center text-center transition",
                    clickable ? "cursor-pointer" : "cursor-default",
                  ].join(" ")}
                >
                  <div
                    className={[
                      "grid h-9 w-9 place-items-center rounded-full border text-sm font-black shadow-sm transition",
                      current
                        ? "border-zinc-950 bg-zinc-950 text-white"
                        : completed
                          ? "border-zinc-950 bg-white text-zinc-950"
                          : locked
                            ? "border-zinc-200 bg-white text-zinc-400"
                            : "border-zinc-300 bg-white text-zinc-600",
                      clickable ? "group-hover:scale-[1.04]" : "",
                    ].join(" ")}
                  >
                    {step.key === "cart" ? (
                      <ShoppingBag className="h-4 w-4" />
                    ) : completed ? (
                      <Check className="h-4 w-4" />
                    ) : locked ? (
                      <Lock className="h-3.5 w-3.5" />
                    ) : (
                      step.id
                    )}
                  </div>

                  <div
                    className={[
                      "mt-2 text-[12px] font-black",
                      current ? "text-zinc-950" : "text-zinc-600",
                    ].join(" ")}
                  >
                    {step.title}
                  </div>

                  <div
                    className={[
                      "mt-1 inline-flex rounded-full px-2 py-0.5 text-[10px] font-black",
                      current
                        ? "bg-zinc-950 text-white"
                        : completed
                          ? "bg-zinc-100 text-zinc-700"
                          : "bg-zinc-100 text-zinc-500",
                    ].join(" ")}
                  >
                    {getStatusLabel(step.key, activeVisual, done)}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}