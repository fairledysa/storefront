// FILE: apps/storefront/src/app/checkout/_components/PaymentStep.tsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import StepShell from "./StepShell";
import { Button } from "@/components/ui/button";
import { CreditCard } from "lucide-react";

type PaymentOption = {
  id: string;
  type: "cod" | "bank_transfer" | "provider";
  title: string;
  subtitle?: string | null;
  fee_text?: string | null;
  recommended?: boolean;
  disabled?: boolean;
  disabled_reason?: string | null;
};

async function safeJson(r: Response) {
  try {
    return await r.json();
  } catch {
    return null;
  }
}

function refreshSummary() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("checkout:refresh"));
  }
}

function setSubmitEnabled(enabled: boolean) {
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("checkout:submitEnabled", {
        detail: { enabled },
      }),
    );
  }
}

export type PaymentStepProps = {
  isActive: boolean;
  isDone: boolean;
  isLocked: boolean;
  onEdit: () => void;
  onConfirm: () => void;
  confirmedId?: string;
};

function PaymentSkeleton() {
  return (
    <div className="grid gap-1.5 sm:grid-cols-2 sm:gap-2.5">
      {Array.from({ length: 2 }).map((_, i) => (
        <div
          key={i}
          className={[
            "rounded-[18px] px-3 py-3 sm:rounded-[20px] sm:border sm:border-zinc-200 sm:bg-white sm:p-3.5",
            "border border-transparent bg-transparent",
          ].join(" ")}
        >
          <div className="h-4 w-36 animate-pulse rounded-full bg-zinc-100" />
          <div className="mt-2 h-3 w-44 animate-pulse rounded-full bg-zinc-100" />
          <div className="mt-2 h-3 w-24 animate-pulse rounded-full bg-zinc-100" />
        </div>
      ))}
    </div>
  );
}

export default function PaymentStep({
  isActive,
  isDone,
  isLocked,
  onEdit,
  onConfirm,
  confirmedId,
}: PaymentStepProps) {
  const [loading, setLoading] = useState(false);
  const [options, setOptions] = useState<PaymentOption[]>([]);
  const [method, setMethod] = useState<string>(confirmedId ?? "");
  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState(false);

  const reqSeq = useRef(0);
  const lastSynced = useRef<string>("");

  async function loadOptions() {
    setLoading(true);

    try {
      const r = await fetch("/api/checkout/payment/options", { method: "GET" });
      const j = await safeJson(r);

      const list: PaymentOption[] = Array.isArray(j?.options) ? j.options : [];
      setOptions(list);

      if (confirmedId) {
        setMethod(confirmedId);
        lastSynced.current = confirmedId;
      } else if (method) {
        const still = list.find((x) => x.id === method && !x.disabled);

        if (!still) {
          const rec = list.find((x) => x.recommended && !x.disabled);
          const first = list.find((x) => !x.disabled);
          setMethod((rec ?? first ?? list[0])?.id ?? "");
        }
      } else {
        const rec = list.find((x) => x.recommended && !x.disabled);
        const first = list.find((x) => !x.disabled);
        setMethod((rec ?? first ?? list[0])?.id ?? "");
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (isLocked) {
      setSubmitEnabled(false);
      return;
    }

    loadOptions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLocked]);

  useEffect(() => {
    const enabled = Boolean(isActive && !isLocked && method);
    setSubmitEnabled(enabled);
  }, [isActive, isLocked, method]);

  const picked = useMemo(() => {
    const id = confirmedId ?? method;
    return options.find((m) => m.id === id);
  }, [confirmedId, method, options]);

  async function persistSelection(nextId: string) {
    if (isLocked || !isActive) return;
    if (!nextId) return;
    if (lastSynced.current === nextId) return;

    const row = options.find((x) => x.id === nextId);
    if (row?.disabled) return;

    const mySeq = ++reqSeq.current;
    setSaving(true);

    try {
      const r = await fetch("/api/checkout/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payment_method: nextId }),
      });

      const j = await safeJson(r);

      if (mySeq !== reqSeq.current) return;
      if (!r.ok || !j?.ok) return;

      lastSynced.current = nextId;
      refreshSummary();
    } finally {
      if (mySeq === reqSeq.current) setSaving(false);
    }
  }

  function onPick(nextId: string) {
    setMethod(nextId);
    persistSelection(nextId);
  }

  async function confirmPayment() {
    const id = method;
    if (!id) return;

    const row = options.find((x) => x.id === id);
    if (row?.disabled) return;

    setBusy(true);

    try {
      const r = await fetch("/api/checkout/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payment_method: id }),
      });

      const j = await safeJson(r);

      if (!r.ok || !j?.ok) {
        console.error(j?.error || "PAYMENT_CONFIRM_FAILED");
        return;
      }

      lastSynced.current = id;
      refreshSummary();
      onConfirm();
    } finally {
      setBusy(false);
    }
  }

  if (isDone && picked) {
    return (
      <StepShell
        title="الدفع"
        subtitle="تم اختيار طريقة الدفع — يمكنك تعديلها قبل التأكيد"
        icon={<CreditCard className="h-5 w-5 text-zinc-800" />}
        isActive={isActive}
        isDone
        isLocked={false}
        onEdit={onEdit}
      >
        <div className="rounded-[18px] border border-amber-700/25 bg-[#fffaf1] px-3 py-3 sm:rounded-[22px] sm:p-4">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <div className="text-sm font-black text-zinc-950">
              {picked.title}
            </div>

            <span className="rounded-full border border-amber-900/15 bg-white px-2 py-0.5 text-[11px] font-black text-stone-700 sm:text-[12px]">
              محدد
            </span>

            {picked.recommended ? (
              <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] text-zinc-500 sm:text-[12px]">
                موصى به
              </span>
            ) : null}
          </div>

          {picked.subtitle ? (
            <div className="mt-1 text-[12px] leading-6 text-zinc-500 sm:text-[13px]">
              {picked.subtitle}
            </div>
          ) : null}

          {picked.fee_text ? (
            <div className="mt-2 inline-flex max-w-full rounded-full border border-zinc-200 bg-white px-2.5 py-1 text-[11px] leading-5 text-zinc-500 sm:text-[12px]">
              {picked.fee_text}
            </div>
          ) : null}
        </div>
      </StepShell>
    );
  }

  const disabledUI = isLocked || !isActive;

  return (
    <StepShell
      title="الدفع"
      subtitle={isLocked ? "أكمل الشحن أولًا" : "اختر طريقة الدفع المناسبة"}
      icon={<CreditCard className="h-5 w-5 text-zinc-800" />}
      isActive={isActive}
      isDone={false}
      isLocked={isLocked}
      rightChip={<span>الخطوة 3</span>}
    >
      {loading ? (
        <PaymentSkeleton />
      ) : options.length === 0 ? (
        <div className="rounded-[18px] border border-dashed border-zinc-200 bg-zinc-50 px-4 py-5 text-center sm:rounded-[20px]">
          <div className="text-sm font-black text-zinc-800">
            لا توجد طرق دفع متاحة
          </div>

          <div className="mt-1 text-[13px] leading-6 text-zinc-500">
            جرّب لاحقًا أو تواصل مع المتجر.
          </div>
        </div>
      ) : (
        <div
          className={[
            "grid gap-1.5 sm:grid-cols-2 sm:gap-2.5",
            disabledUI || saving ? "pointer-events-none opacity-80" : "",
          ].join(" ")}
        >
          {options.map((option) => {
            const selected = option.id === method;

            return (
              <button
                key={option.id}
                type="button"
                onClick={() => {
                  if (option.disabled) return;
                  onPick(option.id);
                }}
                className={[
                  "rounded-[18px] px-3 py-3 text-right transition active:scale-[0.997] sm:rounded-[22px] sm:border sm:p-3.5",
                  selected
                    ? "border border-amber-700/30 bg-[#fffaf1] shadow-none sm:shadow-[0_12px_32px_rgba(15,23,42,0.055)]"
                    : "border border-transparent bg-transparent hover:bg-zinc-50 sm:border-zinc-200 sm:bg-white",
                  option.disabled
                    ? "cursor-not-allowed opacity-60"
                    : "cursor-pointer",
                ].join(" ")}
                aria-disabled={option.disabled ? "true" : "false"}
              >
                <div className="flex items-start gap-2.5 sm:gap-3">
                  <div
                    className={[
                      "mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full border text-sm font-black",
                      selected
                        ? "border-zinc-950 bg-zinc-950 text-white"
                        : "border-zinc-200 bg-white text-transparent",
                    ].join(" ")}
                  >
                    ✓
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex min-w-0 flex-wrap items-center gap-1.5 sm:gap-2">
                      <div className="min-w-0 max-w-full truncate text-sm font-black text-zinc-950">
                        {option.title}
                      </div>

                      {selected ? (
                        <span className="rounded-full border border-amber-900/15 bg-white px-2 py-0.5 text-[11px] font-black text-stone-700 sm:text-[12px]">
                          محدد
                        </span>
                      ) : null}

                      {option.recommended ? (
                        <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] text-zinc-500 sm:bg-zinc-50 sm:text-[12px]">
                          موصى به
                        </span>
                      ) : null}
                    </div>

                    {option.subtitle ? (
                      <div className="mt-1.5 line-clamp-2 text-[12px] leading-5 text-zinc-500 sm:text-[13px]">
                        {option.subtitle}
                      </div>
                    ) : null}

                    {option.fee_text ? (
                      <div className="mt-2 inline-flex max-w-full rounded-full border border-zinc-200 bg-white px-2.5 py-1 text-[11px] leading-5 text-zinc-500 sm:text-[12px]">
                        {option.fee_text}
                      </div>
                    ) : null}

                    {selected && saving ? (
                      <div className="mt-2 text-[12px] leading-5 text-zinc-500">
                        تحديث الملخص...
                      </div>
                    ) : null}

                    {option.disabled && option.disabled_reason ? (
                      <div className="mt-2 text-[12px] leading-5 text-zinc-500">
                        {option.disabled_reason}
                      </div>
                    ) : option.disabled ? (
                      <div className="mt-2 text-[12px] leading-5 text-zinc-500">
                        غير متاح
                      </div>
                    ) : null}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {!loading && picked?.type === "bank_transfer" ? (
        <div className="mt-3 rounded-[18px] border border-zinc-200 bg-zinc-50/80 px-3 py-3 sm:rounded-[20px] sm:p-4">
          <div className="text-sm font-black text-zinc-950">
            بيانات التحويل البنكي
          </div>

          <div className="mt-1 text-[12px] leading-6 text-zinc-500 sm:text-[13px]">
            حوّل المبلغ إلى الحساب التالي، ثم أرسل صورة الإيصال لخدمة العملاء
            ليتم اعتماد طلبك.
          </div>

          <div className="mt-3 rounded-2xl border border-zinc-200 bg-white px-3 py-2.5 sm:p-3">
            <div className="text-[13px] font-black text-zinc-950">
              {picked.title}
            </div>

            {picked.subtitle ? (
              <div className="mt-1 text-[12px] leading-relaxed text-zinc-500 sm:text-[13px]">
                {picked.subtitle}
              </div>
            ) : (
              <div className="mt-1 text-[12px] text-zinc-500 sm:text-[13px]">
                لا توجد بيانات تحويل حالياً.
              </div>
            )}
          </div>
        </div>
      ) : null}

      {!loading && picked?.type === "provider" ? (
        <div className="mt-3 rounded-[18px] border border-zinc-200 bg-zinc-50/80 px-3 py-3 sm:rounded-[20px] sm:p-4">
          <div className="text-sm font-black text-zinc-950">بوابة الدفع</div>

          <div className="mt-1 text-[12px] leading-6 text-zinc-500 sm:text-[13px]">
            عند تأكيد الطلب سيتم تحويلك إلى بوابة دفع آمنة لإكمال العملية.
          </div>
        </div>
      ) : null}

      <Button
        className="mt-3 h-11 w-full rounded-[18px] bg-zinc-950 text-[14px] font-black text-white shadow-[0_12px_28px_rgba(15,23,42,0.14)] transition hover:bg-zinc-800 active:scale-[0.99] disabled:bg-zinc-200 disabled:text-zinc-400 disabled:shadow-none sm:mt-4 sm:h-12 sm:rounded-[20px] sm:text-[15px]"
        type="button"
        disabled={isLocked || !isActive || loading || busy || saving || !method}
        onClick={confirmPayment}
      >
        {busy || saving ? "جاري الاعتماد..." : "اعتماد طريقة الدفع"}
      </Button>
    </StepShell>
  );
}