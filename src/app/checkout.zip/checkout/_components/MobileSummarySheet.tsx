// FILE: apps/storefront/src/app/checkout/_components/MobileSummarySheet.tsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { ArrowLeft, ShieldCheck, Ticket } from "lucide-react";

type Summary = {
  cart_id: string;
  currency: string;
  subtotal: number;
  discount: number;
  shipping: number;
  payment_fee?: number;
  payment_method?: string | null;
  total: number;
  coupon: null | { code: string; discount: number };
};

type SummaryPatchEventDetail = {
  patch?: Partial<
    Pick<
      Summary,
      "shipping" | "discount" | "payment_fee" | "payment_method" | "total"
    >
  >;
  summary?: Summary;
  reconcile?: boolean;
};

type ApiErrorResponse = {
  ok?: boolean;
  error?: string;
  message_ar?: string;
  summary?: Summary;
  order?: any;
};

function n(x: any) {
  const v = Number(x ?? 0);
  return Number.isFinite(v) ? v : 0;
}

function round2(x: number) {
  return Math.round(x * 100) / 100;
}

function applyPatch(base: Summary, patch: Partial<Summary>): Summary {
  const next: Summary = { ...base, ...patch };

  const subtotal = n(next.subtotal);
  const shipping = n(next.shipping);
  const payment_fee = n(next.payment_fee);
  const discount = n(next.discount);

  next.total = round2(
    Math.max(0, subtotal - discount) + shipping + payment_fee,
  );

  return next;
}

function extractThankYouToken(j: any): string | null {
  const o = j?.order ?? j?.data?.order ?? null;
  const token =
    o?.public_token ??
    o?.publicToken ??
    o?.public_no ??
    o?.publicNo ??
    o?.order_number ??
    o?.orderNumber ??
    o?.order_no ??
    o?.orderNo ??
    null;

  if (token == null) return null;
  const value = String(token).trim();
  return value ? value : null;
}

export default function MobileSummarySheet() {
  const [open, setOpen] = useState(false);

  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [softLoading, setSoftLoading] = useState(false);

  const [submitBusy, setSubmitBusy] = useState(false);
  const [canSubmit, setCanSubmit] = useState(false);

  const [couponCode, setCouponCode] = useState("");
  const [couponBusy, setCouponBusy] = useState(false);
  const [couponErrorMsg, setCouponErrorMsg] = useState<string | null>(null);

  const [submitErrorMsg, setSubmitErrorMsg] = useState<string | null>(null);

  const currency = summary?.currency ?? "SAR";
  const hasTotals = Boolean(summary);

  const subtotal = summary ? n(summary.subtotal) : null;
  const shipping = summary ? n(summary.shipping) : null;
  const payment_fee = summary ? n(summary.payment_fee) : 0;
  const discount = summary ? n(summary.discount) : null;
  const total = summary ? n(summary.total) : null;

  const showPaymentFee = payment_fee > 0;
  const hasCouponApplied = Boolean(summary?.coupon?.code);

  const abortRef = useRef<AbortController | null>(null);
  const seqRef = useRef(0);

  async function fetchPrepare(reason?: string, opts?: { soft?: boolean }) {
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    const seq = ++seqRef.current;

    if (opts?.soft) setSoftLoading(true);
    else setLoading(true);

    try {
      const r = await fetch("/api/checkout/prepare", {
        method: "GET",
        signal: ac.signal,
        headers: { "Cache-Control": "no-store" },
      });

      const j = await r.json().catch(() => ({}));
      if (seq !== seqRef.current) return;

      if (!r.ok || !j?.ok) throw new Error(j?.error || "PREPARE_FAILED");

      const s: Summary = j.summary;
      setSummary(s);

      if (s?.coupon?.code) setCouponCode(String(s.coupon.code));
      else setCouponCode("");

      setCouponErrorMsg(null);
    } catch (e: any) {
      if (e?.name === "AbortError") return;
      setSummary((prev) => prev ?? null);
    } finally {
      if (seq === seqRef.current) {
        if (opts?.soft) setSoftLoading(false);
        else setLoading(false);
      }
    }
  }

  useEffect(() => {
    fetchPrepare("mount");

    const onRefresh = () => {
      fetchPrepare("refresh", { soft: true });
    };

    const onSummaryPatch = (evt: Event) => {
      const e = evt as CustomEvent<SummaryPatchEventDetail>;
      const detail = e?.detail || {};

      if (detail.summary) {
        setSummary(detail.summary);

        if (detail.summary?.coupon?.code) {
          setCouponCode(String(detail.summary.coupon.code));
        } else {
          setCouponCode("");
        }

        setCouponErrorMsg(null);
      }

      if (detail.patch) {
        setSummary((prev) => {
          if (!prev) return prev;
          return applyPatch(prev, detail.patch as Partial<Summary>);
        });
      }

      const reconcile = detail.reconcile !== false;
      if (reconcile) {
        fetchPrepare("reconcile", { soft: true });
      }
    };

    const onSubmitEnabled = (evt: Event) => {
      const e = evt as CustomEvent<{ enabled?: boolean }>;
      setCanSubmit(Boolean(e?.detail?.enabled));
    };

    window.addEventListener("checkout:refresh", onRefresh as EventListener);
    window.addEventListener(
      "checkout:summaryPatch",
      onSummaryPatch as EventListener,
    );
    window.addEventListener(
      "checkout:submitEnabled",
      onSubmitEnabled as EventListener,
    );

    return () => {
      window.removeEventListener(
        "checkout:refresh",
        onRefresh as EventListener,
      );
      window.removeEventListener(
        "checkout:summaryPatch",
        onSummaryPatch as EventListener,
      );
      window.removeEventListener(
        "checkout:submitEnabled",
        onSubmitEnabled as EventListener,
      );
      abortRef.current?.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function applyCoupon() {
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    setCouponBusy(true);
    setCouponErrorMsg(null);

    try {
      const r = await fetch("/api/checkout/apply-coupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });

      const j = (await r.json().catch(() => ({}))) as ApiErrorResponse;

      if (!r.ok || !j?.ok) {
        throw new Error(j?.message_ar || j?.error || "APPLY_COUPON_FAILED");
      }

      const s: Summary = j.summary as Summary;
      setSummary(s);
      if (s?.coupon?.code) setCouponCode(String(s.coupon.code));

      setCouponErrorMsg(null);
    } catch (e: any) {
      setCouponErrorMsg(e?.message || "تعذر تطبيق الكوبون.");
    } finally {
      setCouponBusy(false);
    }
  }

  async function removeCoupon() {
    setCouponBusy(true);
    setCouponErrorMsg(null);

    try {
      const r = await fetch("/api/checkout/remove-coupon", { method: "POST" });
      const j = (await r.json().catch(() => ({}))) as ApiErrorResponse;

      if (!r.ok || !j?.ok) {
        throw new Error(j?.message_ar || j?.error || "REMOVE_COUPON_FAILED");
      }

      const s: Summary = j.summary as Summary;
      setSummary(s);
      setCouponCode("");

      setCouponErrorMsg(null);
    } catch (e: any) {
      setCouponErrorMsg(e?.message || "تعذر إزالة الكوبون.");
    } finally {
      setCouponBusy(false);
    }
  }

  async function submitOrder() {
    if (!canSubmit) {
      setOpen(true);
      setSubmitErrorMsg("أكمل العنوان والشحن وطريقة الدفع أولًا.");
      return;
    }

    setSubmitBusy(true);
    setSubmitErrorMsg(null);

    try {
      const r = await fetch("/api/checkout/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      const j = (await r.json().catch(() => ({}))) as ApiErrorResponse;

      if (!r.ok || !j?.ok) {
        throw new Error(j?.message_ar || j?.error || "SUBMIT_FAILED");
      }

      const token = extractThankYouToken(j);
      if (!token) {
        throw new Error("ORDER_TOKEN_MISSING");
      }

      setOpen(false);
      window.location.href = `/thankyou/${encodeURIComponent(token)}`;
    } catch (e: any) {
      const msg =
        e?.message === "ORDER_TOKEN_MISSING"
          ? "تم إنشاء الطلب لكن لم يصل رقم الطلب من السيرفر."
          : e?.message || "تعذر إتمام الطلب.";
      setSubmitErrorMsg(msg);
    } finally {
      setSubmitBusy(false);
    }
  }

  const summaryBusy = loading || softLoading || submitBusy || !hasTotals;

  const ctaLabel = useMemo(() => {
    if (submitBusy) return "جاري التأكيد...";
    if (!canSubmit) return "أكمل الخطوات";
    return "تأكيد الدفع";
  }, [submitBusy, canSubmit]);

  return (
    <>
      <div aria-hidden className="h-[96px] lg:hidden" />

      <div className="fixed inset-x-0 bottom-0 z-50 border-t border-zinc-200 bg-white/96 shadow-[0_-10px_30px_rgba(15,23,42,0.09)] backdrop-blur-xl lg:hidden">
        <div className="mx-auto max-w-7xl px-3 pb-[calc(0.55rem+env(safe-area-inset-bottom))] pt-2">
          <div className="grid grid-cols-[minmax(0,1fr)_132px] items-center gap-2">
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="group flex h-[52px] min-w-0 items-center justify-between rounded-[22px] border border-zinc-200 bg-zinc-50 px-3 text-right transition active:scale-[0.99]"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <Badge
                    variant="secondary"
                    className="h-5 rounded-full border border-zinc-200 bg-white px-1.5 text-[10px] font-black text-zinc-500"
                  >
                    {currency}
                  </Badge>
                  <span className="text-[10px] font-bold text-zinc-500">
                    إجمالي الطلب
                  </span>
                </div>

                <div className="mt-0.5">
                  {total == null || softLoading ? (
                    <span className="inline-block h-5 w-20 animate-pulse rounded-full bg-zinc-200" />
                  ) : (
                    <span
                      dir="ltr"
                      className="block truncate text-[17px] font-black leading-6 tracking-tight text-zinc-950"
                    >
                      {formatMoney(currency, total)}
                    </span>
                  )}
                </div>
              </div>

              <span className="ms-2 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-2xl border border-zinc-200 bg-white text-xs font-black text-zinc-800 transition group-hover:bg-zinc-50">
                ↑
              </span>
            </button>

            <Button
              className={[
                "h-[52px] rounded-[22px] px-2 text-[13px] font-black text-white",
                "shadow-[0_10px_24px_rgba(15,23,42,0.18)] transition active:scale-[0.99]",
                canSubmit
                  ? "bg-zinc-950 hover:bg-zinc-800"
                  : "bg-zinc-700 hover:bg-zinc-800",
                "disabled:bg-zinc-300 disabled:text-white disabled:shadow-none",
              ].join(" ")}
              disabled={summaryBusy}
              onClick={submitOrder}
            >
              <span className="whitespace-nowrap">{ctaLabel}</span>
            </Button>
          </div>

          {submitErrorMsg && !open ? (
            <div className="mt-1.5 rounded-2xl bg-red-50 px-3 py-1.5 text-center text-[11px] leading-5 text-red-600">
              {submitErrorMsg}
            </div>
          ) : null}
        </div>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent
          side="bottom"
          className="max-h-[82svh] overflow-y-auto rounded-t-[26px] border-t border-zinc-200 bg-white p-0"
        >
          <div className="px-4 pb-4 pt-3">
            <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-zinc-200" />

            <SheetHeader className="space-y-1">
              <div className="flex items-center justify-between">
                <SheetTitle className="text-base font-black text-zinc-950">
                  تفاصيل الطلب
                </SheetTitle>

                <Badge
                  variant="secondary"
                  className="rounded-full border border-zinc-200 bg-zinc-50 text-zinc-600"
                >
                  {currency}
                </Badge>
              </div>

              <div className="text-xs text-zinc-500">
                راجع ملخص الطلب قبل التأكيد
              </div>
            </SheetHeader>

            <div className="mt-4 rounded-[22px] border border-zinc-200 bg-zinc-50 p-4">
              <div className="space-y-3 text-sm">
                <Row
                  label="ملخص السلة"
                  value={
                    subtotal == null || softLoading
                      ? null
                      : formatMoney(currency, subtotal)
                  }
                />

                <Row
                  label="الشحن"
                  value={
                    shipping == null || softLoading
                      ? null
                      : formatMoney(currency, shipping)
                  }
                />

                {showPaymentFee ? (
                  <Row
                    label="رسوم الدفع عند الاستلام"
                    value={
                      softLoading ? null : formatMoney(currency, payment_fee)
                    }
                  />
                ) : null}

                {discount != null && discount > 0 && !softLoading ? (
                  <div className="flex items-center justify-between">
                    <div className="text-zinc-500">خصم</div>
                    <div dir="ltr" className="font-black text-amber-800">
                      - {formatMoney(currency, discount)}
                    </div>
                  </div>
                ) : null}

                <Separator className="my-1 bg-zinc-200" />

                <div className="flex items-end justify-between gap-3">
                  <div>
                    <div className="font-black text-zinc-950">الإجمالي</div>
                    <div className="text-xs text-zinc-500">
                      شامل الشحن{showPaymentFee ? " ورسوم الدفع" : ""}
                    </div>
                  </div>

                  {total == null || softLoading ? (
                    <SkeletonText widthClass="w-28" heightClass="h-7" />
                  ) : (
                    <div
                      dir="ltr"
                      className="text-2xl font-black tracking-tight text-zinc-950"
                    >
                      {formatMoney(currency, total)}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-3 rounded-[22px] border border-zinc-200 bg-white p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl border border-zinc-200 bg-zinc-50 text-zinc-700">
                    <Ticket className="h-4 w-4" />
                  </span>

                  <div>
                    <div className="text-sm font-black text-zinc-950">
                      كوبون خصم
                    </div>
                    <div className="text-xs text-zinc-500">
                      يُطبّق مباشرة على الإجمالي
                    </div>
                  </div>
                </div>

                <Badge
                  variant="secondary"
                  className="rounded-full border border-zinc-200 bg-zinc-50 text-zinc-500"
                >
                  اختياري
                </Badge>
              </div>

              <div className="mt-3 flex gap-2">
                <Input
                  placeholder="أدخل رمز الكوبون"
                  value={couponCode}
                  onChange={(e) => {
                    setCouponCode(e.target.value);
                    if (couponErrorMsg) setCouponErrorMsg(null);
                  }}
                  className="h-11 rounded-2xl border-zinc-200 bg-white"
                  disabled={couponBusy}
                />

                <Button
                  className="h-11 rounded-2xl bg-zinc-950 px-5 text-[13px] font-black text-white hover:bg-zinc-800 disabled:bg-zinc-300 disabled:text-white"
                  disabled={
                    couponBusy || (!hasCouponApplied && !couponCode.trim())
                  }
                  onClick={hasCouponApplied ? removeCoupon : applyCoupon}
                >
                  {couponBusy ? "..." : hasCouponApplied ? "إزالة" : "تطبيق"}
                </Button>
              </div>

              {couponErrorMsg ? (
                <div className="mt-2 text-right text-[12px] text-red-600">
                  {couponErrorMsg}
                </div>
              ) : null}
            </div>

            <div className="mt-4">
              <Button
                className={[
                  "h-12 w-full rounded-[24px] text-base font-black text-white",
                  "shadow-[0_12px_30px_rgba(15,23,42,0.18)]",
                  canSubmit
                    ? "bg-zinc-950 hover:bg-zinc-800"
                    : "bg-zinc-700 hover:bg-zinc-800",
                  "disabled:bg-zinc-300 disabled:text-white disabled:shadow-none",
                ].join(" ")}
                disabled={summaryBusy}
                onClick={submitOrder}
              >
                {ctaLabel}
              </Button>

              {submitErrorMsg ? (
                <div className="mt-2 rounded-2xl bg-red-50 px-3 py-2 text-center text-[11px] leading-5 text-red-600">
                  {submitErrorMsg}
                </div>
              ) : null}

              <div className="mt-3 flex items-center justify-between text-[11px] text-zinc-500">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4" />
                  دفع آمن
                </span>

                <Link
                  href="/cart"
                  className="inline-flex items-center gap-1 font-bold transition hover:text-zinc-950"
                >
                  رجوع للسلة <ArrowLeft className="h-3.5 w-3.5" />
                </Link>
              </div>

              <div className="mt-2 text-center text-[11px] leading-relaxed text-zinc-500">
                بالضغط على “تأكيد الدفع” سيتم إنشاء الطلب ومتابعته حسب بياناتك
                المختارة.
              </div>
            </div>

            <div className="h-6" />
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}

function Row({ label, value }: { label: string; value: string | null }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="text-zinc-500">{label}</div>
      {value == null ? (
        <SkeletonText widthClass="w-16" heightClass="h-4" />
      ) : (
        <div dir="ltr" className="font-black text-zinc-950">
          {value}
        </div>
      )}
    </div>
  );
}

function SkeletonText({
  widthClass,
  heightClass,
}: {
  widthClass: string;
  heightClass: string;
}) {
  return (
    <div
      className={`animate-pulse rounded-full bg-zinc-200 ${widthClass} ${heightClass}`}
      aria-hidden
    />
  );
}

function formatMoney(currency: string, v: number) {
  return `${currency} ${Number(v).toLocaleString("en-US")}`;
}