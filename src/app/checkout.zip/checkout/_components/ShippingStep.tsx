// FILE: apps/storefront/src/app/checkout/_components/ShippingStep.tsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import StepShell from "./StepShell";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Truck } from "lucide-react";

type Shipping = {
  id: string;
  name: string;
  eta: string;
  price: string;
  recommended?: boolean;
};

async function safeJson(r: Response) {
  try {
    return await r.json();
  } catch {
    return null;
  }
}

function refreshSummary() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("checkout:refresh"));
  }
}

function ShippingSkeleton() {
  return (
    <div className="-mt-1 space-y-1 sm:mt-0 sm:space-y-2">
      {Array.from({ length: 2 }).map((_, i) => (
        <div
          key={i}
          className={[
            "rounded-[16px] px-2.5 py-2.5",
            "border border-transparent bg-transparent",
            "sm:rounded-[20px] sm:border-zinc-200 sm:bg-white sm:p-3.5",
          ].join(" ")}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0 flex-1">
              <div className="h-4 w-32 animate-pulse rounded-full bg-zinc-100" />
              <div className="mt-2 h-3 w-20 animate-pulse rounded-full bg-zinc-100" />
            </div>

            <div className="h-4 w-14 animate-pulse rounded-full bg-zinc-100" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function ShippingStep(props: {
  isActive: boolean;
  isDone: boolean;
  isLocked: boolean;
  confirmedId?: string;
  onEdit: () => void;
  onConfirm: (shippingId: string) => void;
}) {
  const { isActive, isDone, isLocked, confirmedId, onEdit, onConfirm } = props;

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [options, setOptions] = useState<Shipping[]>([]);
  const [value, setValue] = useState<string>(confirmedId ?? "");

  const reqSeq = useRef(0);
  const lastSynced = useRef<string>("");

  async function loadOptions() {
    setLoading(true);

    try {
      const r = await fetch("/api/checkout/shipping/options", {
        method: "GET",
      });

      const j = await safeJson(r);
      const list: Shipping[] = Array.isArray(j?.options) ? j.options : [];
      setOptions(list);

      if (confirmedId) {
        setValue(confirmedId);
        lastSynced.current = confirmedId;
      } else if (!value && list[0]?.id) {
        setValue(list[0].id);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (isLocked) return;
    loadOptions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLocked]);

  const picked = useMemo(() => {
    const id = confirmedId ?? value;
    return options.find((x) => x.id === id);
  }, [confirmedId, value, options]);

  async function persistSelection(nextId: string) {
    if (isLocked || !isActive) return;
    if (!nextId) return;
    if (lastSynced.current === nextId) return;

    const mySeq = ++reqSeq.current;
    setSaving(true);

    try {
      const r = await fetch("/api/checkout/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shipping_id: nextId }),
      });

      const j = await safeJson(r);

      if (mySeq !== reqSeq.current) return;
      if (!r.ok || !j?.ok) return;

      lastSynced.current = nextId;
      refreshSummary();
    } finally {
      if (mySeq === reqSeq.current) setSaving(false);
    }
  }

  function onPick(nextId: string) {
    setValue(nextId);
    persistSelection(nextId);
  }

  if (isDone && picked) {
    return (
      <StepShell
        title="شركة الشحن"
        subtitle="تم اختيار طريقة الشحن — يمكنك تعديلها قبل الدفع"
        icon={<Truck className="h-5 w-5 text-zinc-800" />}
        isActive={isActive}
        isDone
        isLocked={false}
        onEdit={onEdit}
      >
        <div className="rounded-[18px] border border-amber-700/25 bg-[#fffaf1] px-3 py-3 sm:rounded-[22px] sm:p-4">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <div className="min-w-0 truncate text-sm font-black text-zinc-950">
              {picked.name}
            </div>

            <span className="rounded-full border border-amber-900/15 bg-white px-2 py-0.5 text-[11px] font-black text-stone-700 sm:text-[12px]">
              محدد
            </span>

            <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] text-zinc-500 sm:text-[12px]">
              {picked.eta}
            </span>

            {picked.recommended ? (
              <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] text-zinc-500 sm:text-[12px]">
                موصى به
              </span>
            ) : null}
          </div>

          <div className="mt-2.5 flex items-center justify-between gap-3 text-[13px]">
            <div className="text-zinc-500">تكلفة الشحن</div>

            <div dir="ltr" className="font-black text-zinc-950">
              {picked.price}
            </div>
          </div>
        </div>
      </StepShell>
    );
  }

  return (
    <StepShell
      title="شركة الشحن"
      subtitle={
        isLocked ? "أكمل عنوان الشحن أولًا" : "اختر طريقة التوصيل المناسبة"
      }
      icon={<Truck className="h-5 w-5 text-zinc-800" />}
      isActive={isActive}
      isDone={false}
      isLocked={isLocked}
      rightChip={<span>الخطوة 2</span>}
    >
      <div className="-mt-1 sm:mt-0">
        {loading ? (
          <ShippingSkeleton />
        ) : options.length === 0 ? (
          <div className="rounded-[18px] border border-dashed border-zinc-200 bg-zinc-50 px-4 py-5 text-center sm:rounded-[20px]">
            <div className="text-sm font-black text-zinc-800">
              لا توجد خيارات شحن متاحة
            </div>

            <div className="mt-1 text-[13px] leading-6 text-zinc-500">
              تأكد من اختيار عنوان صحيح أو جرّب لاحقًا.
            </div>
          </div>
        ) : (
          <RadioGroup
            value={value}
            onValueChange={onPick}
            className="space-y-1 sm:space-y-2"
            disabled={isLocked || !isActive || loading}
          >
            {options.map((option) => {
              const selected = option.id === value;
              const inputId = `checkout-shipping-${option.id}`;

              return (
                <div
                  key={option.id}
                  className={[
                    "group rounded-[17px] border px-2.5 py-2.5 transition active:scale-[0.997]",
                    "sm:rounded-[22px] sm:px-3.5 sm:py-3.5",
                    selected
                      ? "border-amber-700/30 bg-[#fffaf1] shadow-none sm:shadow-[0_12px_32px_rgba(15,23,42,0.055)]"
                      : "border-transparent bg-transparent hover:bg-zinc-50 sm:border-zinc-200 sm:bg-white",
                  ].join(" ")}
                >
                  <div className="flex items-start gap-2.5 sm:gap-3">
                    <RadioGroupItem
                      id={inputId}
                      value={option.id}
                      className="mt-1 shrink-0 border-zinc-300 text-zinc-950"
                    />

                    <label
                      htmlFor={inputId}
                      className="min-w-0 flex-1 cursor-pointer"
                    >
                      <div className="flex min-w-0 flex-wrap items-center gap-1.5 sm:gap-2">
                        <div className="min-w-0 max-w-full truncate text-sm font-black text-zinc-950">
                          {option.name}
                        </div>

                        {selected ? (
                          <span className="rounded-full border border-amber-900/15 bg-white px-2 py-0.5 text-[11px] font-black text-stone-700 sm:text-[12px]">
                            محدد
                          </span>
                        ) : null}

                        {option.recommended ? (
                          <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] text-zinc-500 sm:bg-zinc-50 sm:text-[12px]">
                            موصى به
                          </span>
                        ) : null}

                        {selected && saving ? (
                          <span className="rounded-full border border-zinc-200 bg-white px-2 py-0.5 text-[11px] text-zinc-500 sm:text-[12px]">
                            تحديث السعر...
                          </span>
                        ) : null}
                      </div>

                      <div className="mt-1 text-[12px] leading-5 text-zinc-500 sm:mt-1.5 sm:text-[13px]">
                        {option.eta}
                      </div>
                    </label>

                    <div
                      dir="ltr"
                      className="shrink-0 pt-0.5 text-sm font-black text-zinc-950"
                    >
                      {option.price}
                    </div>
                  </div>
                </div>
              );
            })}
          </RadioGroup>
        )}
      </div>

      <Button
        className="mt-3 h-11 w-full rounded-[18px] bg-zinc-950 text-[14px] font-black text-white shadow-[0_12px_28px_rgba(15,23,42,0.14)] transition hover:bg-zinc-800 active:scale-[0.99] disabled:bg-zinc-200 disabled:text-zinc-400 disabled:shadow-none sm:mt-4 sm:h-12 sm:rounded-[20px] sm:text-[15px]"
        disabled={isLocked || !isActive || loading || saving || !value}
        onClick={() => onConfirm(value)}
      >
        {loading
          ? "جاري تحميل الشحن..."
          : saving
            ? "جاري تحديث السعر..."
            : "اعتماد شركة الشحن"}
      </Button>
    </StepShell>
  );
}