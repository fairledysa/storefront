// FILE: apps/storefront/src/app/checkout/_components/StepShell.tsx

"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Pencil } from "lucide-react";

type StepShellProps = {
  title: string;
  subtitle?: string;
  icon: React.ReactNode;

  isActive?: boolean;
  isDone?: boolean;
  isLocked?: boolean;

  onEdit?: () => void;

  children: React.ReactNode;

  rightChip?: React.ReactNode;
};

function Chip({
  children,
  tone = "muted",
}: {
  children: React.ReactNode;
  tone?: "muted" | "success";
}) {
  return (
    <span
      className={[
        "inline-flex items-center rounded-full border",
        "px-2 py-0.5 text-[11px] font-black",
        "sm:px-2.5 sm:py-1 sm:text-[12px]",
        tone === "success"
          ? "border-amber-900/15 bg-[#f7f1e8] text-stone-700"
          : "border-zinc-200 bg-zinc-50 text-zinc-500",
      ].join(" ")}
    >
      {children}
    </span>
  );
}

function IconBadge({
  children,
  done = false,
  active = false,
}: {
  children: React.ReactNode;
  done?: boolean;
  active?: boolean;
}) {
  return (
    <div
      className={[
        "grid shrink-0 place-items-center rounded-[18px] border shadow-sm",
        "h-9 w-9 sm:h-10 sm:w-10 sm:rounded-2xl",
        done
          ? "border-amber-900/15 bg-[#f7f1e8] text-stone-800"
          : active
            ? "border-zinc-950 bg-zinc-950 text-white"
            : "border-zinc-200 bg-zinc-50 text-zinc-700",
      ].join(" ")}
    >
      {children}
    </div>
  );
}

export default function StepShell({
  title,
  subtitle,
  icon,
  isActive = false,
  isDone = false,
  isLocked = false,
  onEdit,
  rightChip,
  children,
}: StepShellProps) {
  const disabled = isLocked || !isActive;

  return (
    <Card
      className={[
        "overflow-hidden border bg-white text-zinc-950",
        "rounded-[22px] sm:rounded-[26px]",
        isActive && !isLocked
          ? "border-zinc-200 shadow-[0_8px_24px_rgba(15,23,42,0.045)] sm:shadow-[0_18px_45px_rgba(15,23,42,0.07)]"
          : "border-zinc-200 shadow-[0_4px_14px_rgba(15,23,42,0.03)] sm:shadow-[0_12px_32px_rgba(15,23,42,0.045)]",
        isDone ? "border-amber-900/15" : "",
        disabled && !isDone ? "opacity-65" : "",
      ].join(" ")}
    >
      <CardContent className="px-3.5 py-3 sm:p-4 lg:p-5">
        <div className="flex items-start justify-between gap-2.5 sm:gap-3">
          <div className="flex min-w-0 items-start gap-2.5 sm:gap-3">
            <IconBadge done={isDone} active={isActive && !isLocked}>
              {icon}
            </IconBadge>

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                <div className="text-[15px] font-black tracking-tight text-zinc-950 sm:text-[16px]">
                  {title}
                </div>

                {isDone ? (
                  <Chip tone="success">
                    <span className="inline-flex items-center gap-1.5">
                      <Check className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                      تم
                    </span>
                  </Chip>
                ) : rightChip ? (
                  <Chip>{rightChip}</Chip>
                ) : null}
              </div>

              {subtitle ? (
                <div className="mt-0.5 text-[12px] leading-5 text-zinc-500 sm:mt-1 sm:text-[13px]">
                  {subtitle}
                </div>
              ) : null}

              {isLocked ? (
                <div className="mt-1.5 text-[12px] text-zinc-500 sm:mt-2">
                  أكمل الخطوة السابقة لفتح هذه الخطوة.
                </div>
              ) : null}
            </div>
          </div>

          {isDone && onEdit ? (
            <Button
              variant="ghost"
              className={[
                "h-8 shrink-0 rounded-2xl border border-zinc-200 bg-white",
                "px-2.5 text-xs font-black text-zinc-800 shadow-sm",
                "transition hover:bg-zinc-50 active:scale-[0.99]",
                "sm:h-9 sm:px-3 sm:text-sm",
              ].join(" ")}
              onClick={onEdit}
            >
              <Pencil className="h-3.5 w-3.5 sm:me-2 sm:h-4 sm:w-4" />
              <span className="hidden sm:inline">تعديل</span>
            </Button>
          ) : null}
        </div>

        <div className="my-2.5 h-px w-full bg-gradient-to-r from-transparent via-zinc-200 to-transparent sm:my-4" />

        <div className={disabled && !isDone ? "pointer-events-none" : ""}>
          {children}
        </div>
      </CardContent>
    </Card>
  );
}