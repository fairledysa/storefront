// FILE: apps/storefront/src/app/checkout/_components/MotionWrap.tsx
"use client";

import { motion } from "framer-motion";

export default function MotionWrap({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
    >
      {children}
    </motion.div>
  );
}
